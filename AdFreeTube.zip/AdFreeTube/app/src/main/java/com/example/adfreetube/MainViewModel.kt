package com.example.adfreetube

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

class MainViewModel : ViewModel() {
    var query by mutableStateOf("")
    var results by mutableStateOf<List<StreamInfoItem>>(emptyList())
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)

    var playingUrl by mutableStateOf<String?>(null)
    var playingTitle by mutableStateOf("")

    private val youtube = ServiceList.YouTube

    fun search() {
        if (query.isBlank()) return
        viewModelScope.launch {
            loading = true
            error = null
            try {
                results = withContext(Dispatchers.IO) {
                    val handler = youtube.searchQHFactory
                        .fromQuery(query, listOf("videos"), "")
                    SearchInfo.getInfo(youtube, handler)
                        .relatedItems
                        .filterIsInstance<StreamInfoItem>()
                }
            } catch (e: Exception) {
                error = e.message ?: "Lỗi không xác định"
            }
            loading = false
        }
    }

    fun play(item: StreamInfoItem) {
        viewModelScope.launch {
            loading = true
            error = null
            try {
                val url = withContext(Dispatchers.IO) {
                    val info = StreamInfo.getInfo(youtube, item.url)
                    // videoStreams = luồng đã gộp sẵn hình + tiếng (tối đa ~720p)
                    info.videoStreams.maxByOrNull { it.height }?.content
                        ?: info.hlsUrl // video trực tiếp (live)
                        ?: throw IllegalStateException("Không tìm thấy luồng phát")
                }
                playingTitle = item.name
                playingUrl = url
            } catch (e: Exception) {
                error = e.message ?: "Không phát được video"
            }
            loading = false
        }
    }

    fun closePlayer() { playingUrl = null }
}
